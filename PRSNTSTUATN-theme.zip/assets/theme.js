(() => {
  function init(root = document) {
    const header = root.querySelector('.site-header');
    if (header && !header.dataset.initialized) {
      header.dataset.initialized = 'true';
      const searchToggle = header.querySelector('.search-toggle');
      const searchPanel = header.querySelector('#SearchPanel');
      const menuToggle = header.querySelector('.mobile-menu-toggle');
      const menu = header.querySelector('#MainNav');
      const closeSearch = () => { searchPanel.hidden = true; searchToggle.setAttribute('aria-expanded', 'false'); };
      const closeMenu = () => { menu.classList.remove('is-open'); menuToggle.setAttribute('aria-expanded', 'false'); };
      searchToggle.addEventListener('click', () => {
        const opening = searchPanel.hidden;
        closeMenu();
        searchPanel.hidden = !opening;
        searchToggle.setAttribute('aria-expanded', String(opening));
        if (opening) header.querySelector('#HeaderSearch').focus();
      });
      header.querySelector('.search-close').addEventListener('click', () => { closeSearch(); searchToggle.focus(); });
      menuToggle.addEventListener('click', () => {
        closeSearch();
        const opening = !menu.classList.contains('is-open');
        menu.classList.toggle('is-open', opening);
        menuToggle.setAttribute('aria-expanded', String(opening));
      });
      menu.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
      header.addEventListener('keydown', event => {
        if (event.key === 'Escape') {
          if (!searchPanel.hidden) { closeSearch(); searchToggle.focus(); }
          else if (menu.classList.contains('is-open')) { closeMenu(); menuToggle.focus(); }
        }
      });
    }
    root.querySelectorAll('.product-form').forEach(form => {
      if (form.dataset.initialized) return;
      form.dataset.initialized = 'true';
      const select = form.querySelector('[name="id"]');
      const button = form.querySelector('[data-add-to-cart]');
      select.addEventListener('change', () => {
        const option = select.selectedOptions[0];
        const available = option.dataset.available === 'true';
        button.disabled = !available;
        button.textContent = available ? 'Add to bag' : 'Sold out';
        const price = form.closest('.product-purchase').querySelector('[data-product-price]');
        if (price) price.textContent = option.dataset.price;
        const url = new URL(window.location.href);
        url.searchParams.set('variant', select.value);
        window.history.replaceState({}, '', url);
      });
      form.addEventListener('submit', async event => {
        if (!window.fetch) return;
        event.preventDefault();
        const status = form.querySelector('.product-form-status');
        button.disabled = true;
        button.textContent = 'Adding…';
        status.textContent = '';
        try {
          const routeRoot = window.Shopify?.routes?.root || '/';
          const response = await fetch(`${routeRoot}cart/add.js`, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } });
          const result = await response.json();
          if (!response.ok) throw new Error(result.description || 'This piece could not be added. Please try again.');
          status.textContent = 'Added to your bag.';
          const toast = document.querySelector('.toast');
          if (toast) {
            toast.textContent = 'A lovely choice. Added to your bag.';
            toast.classList.add('is-visible');
            clearTimeout(window.presentToastTimer);
            window.presentToastTimer = setTimeout(() => toast.classList.remove('is-visible'), 3500);
          }
          try {
            const cartResponse = await fetch(`${routeRoot}cart.js`, { headers: { Accept: 'application/json' } });
            if (cartResponse.ok) {
              const cart = await cartResponse.json();
              document.querySelectorAll('[data-cart-count]').forEach(el => { el.textContent = cart.item_count; });
            }
          } catch { /* The add succeeded; a cart-count refresh must not report an add failure. */ }
        } catch (error) {
          status.textContent = error.message || 'Please try again.';
        } finally {
          button.disabled = select.selectedOptions[0]?.dataset.available !== 'true';
          button.textContent = button.disabled ? 'Sold out' : 'Add to bag';
        }
      });
    });
  }
  init();
  document.addEventListener('shopify:section:load', event => init(event.target));
})();
