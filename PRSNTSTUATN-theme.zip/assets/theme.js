(() => {
  function init(root = document) {
    const header = root.querySelector('.site-header');
    if (header && !header.dataset.initialized) {
      header.dataset.initialized = 'true';
      const searchToggle = header.querySelector('.search-toggle');
      const searchPanel = header.querySelector('#SearchPanel');
      const menuToggle = header.querySelector('.mobile-menu-toggle');
      const menu = header.querySelector('#MainNav');
      const closeSearch = () => { searchPanel.hidden = true; searchToggle.setAttribute('aria-expanded', 'false'); };
      const closeMenu = () => { menu.classList.remove('is-open'); menuToggle.setAttribute('aria-expanded', 'false'); };
      searchToggle.addEventListener('click', () => {
        const opening = searchPanel.hidden;
        closeMenu();
        searchPanel.hidden = !opening;
        searchToggle.setAttribute('aria-expanded', String(opening));
        if (opening) header.querySelector('#HeaderSearch').focus();
      });
      header.querySelector('.search-close').addEventListener('click', () => { closeSearch(); searchToggle.focus(); });
      menuToggle.addEventListener('click', () => {
        closeSearch();
        const opening = !menu.classList.contains('is-open');
        menu.classList.toggle('is-open', opening);
        menuToggle.setAttribute('aria-expanded', String(opening));
      });
      menu.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
      header.addEventListener('keydown', event => {
        if (event.key === 'Escape') {
          if (!searchPanel.hidden) { closeSearch(); searchToggle.focus(); }
          else if (menu.classList.contains('is-open')) { closeMenu(); menuToggle.focus(); }
        }
      });
    }
    root.querySelectorAll('.product-form').forEach(form => {
      if (form.dataset.initialized) return;
      form.dataset.initialized = 'true';
      const select = form.querySelector('[name="id"]');
      const button = form.querySelector('[data-add-to-cart]');
      select.addEventListener('change', () => {
        const option = select.selectedOptions[0];
        const available = option.dataset.available === 'true';
        button.disabled = !available;
        button.textContent = available ? 'Add to bag' : 'Sold out';
        const price = form.closest('.product-purchase').querySelector('[data-product-price]');
        if (price) price.textContent = option.dataset.price;
        const url = new URL(window.location.href);
        url.searchParams.set('variant', select.value);
        window.history.replaceState({}, '', url);
      });
      form.addEventListener('submit', async event => {
        if (!window.fetch) return;
        event.preventDefault();
        const status = form.querySelector('.product-form-status');
        button.disabled = true;
        button.textContent = 'Adding…';
        status.textContent = '';
        try {
          const routeRoot = window.Shopify?.routes?.root || '/';
          const response = await fetch(`${routeRoot}cart/add.js`, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } });
          const result = await response.json();
          if (!response.ok) throw new Error(result.description || 'This piece could not be added. Please try again.');
          status.textContent = 'Added to your bag.';
          document.dispatchEvent(new CustomEvent('present:added'));
          const toast = document.querySelector('.toast');
          if (toast) {
            toast.textContent = 'A lovely choice. Added to your bag.';
            toast.classList.add('is-visible');
            clearTimeout(window.presentToastTimer);
            window.presentToastTimer = setTimeout(() => toast.classList.remove('is-visible'), 3500);
          }
          try {
            const cartResponse = await fetch(`${routeRoot}cart.js`, { headers: { Accept: 'application/json' } });
            if (cartResponse.ok) {
              const cart = await cartResponse.json();
              document.querySelectorAll('[data-cart-count]').forEach(el => { el.textContent = cart.item_count; });
            }
          } catch { /* The add succeeded; a cart-count refresh must not report an add failure. */ }
        } catch (error) {
          status.textContent = error.message || 'Please try again.';
        } finally {
          button.disabled = select.selectedOptions[0]?.dataset.available !== 'true';
          button.textContent = button.disabled ? 'Sold out' : 'Add to bag';
        }
      });
    });
  }
  init();
  document.addEventListener('shopify:section:load', event => init(event.target));
})();

/* Native dialog keeps background content inert and traps keyboard focus. */
(() => {
  const routeRoot = () => window.Shopify?.routes?.root || '/';
  let busy = false;
  let returnFocus = null;
  const drawer = () => document.getElementById('CartDrawer');
  function open() {
    const panel = drawer();
    if (!panel || panel.open) return;
    returnFocus = document.activeElement;
    panel.showModal();
    document.body.classList.add('bag-is-open');
    panel.querySelector('[data-close-cart]')?.focus();
  }
  function close() {
    const panel = drawer();
    if (!panel?.open) return;
    panel.classList.add('is-closing');
    const delay = matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 250;
    setTimeout(() => {
      panel.close(); panel.classList.remove('is-closing');
      document.body.classList.remove('bag-is-open');
      if (returnFocus?.isConnected) returnFocus.focus();
    }, delay);
  }
  function report(error) {
    const area = drawer()?.querySelector('.drawer-error');
    if (area) {
      area.textContent = `${error.message || 'Your bag could not be refreshed.'} `;
      const fallback = document.createElement('a');
      fallback.href = `${routeRoot()}cart`; fallback.textContent = 'View your bag'; fallback.style.textDecoration = 'underline';
      area.append(fallback);
    }
  }
  async function refresh() {
    const response = await fetch(`${routeRoot()}?sections=cart-drawer`, { cache: 'no-store', headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error('Please try again in a moment.');
    const sections = await response.json();
    if (!sections['cart-drawer']) throw new Error('Please view your bag to continue.');
    const parsed = new DOMParser().parseFromString(sections['cart-drawer'], 'text/html');
    const updated = parsed.getElementById('CartDrawer');
    if (!updated) throw new Error('Please view your bag to continue.');
    const panel = drawer();
    // Keep the dialog itself mounted so its native focus trap remains active.
    panel.innerHTML = updated.innerHTML;
    if (panel.open) panel.querySelector('[data-close-cart]')?.focus();
  }
  document.addEventListener('click', async event => {
    const trigger = event.target.closest('[data-open-cart]');
    if (trigger && drawer() && typeof drawer().showModal === 'function') {
      event.preventDefault(); open();
      if (!busy) { busy = true; try { await refresh(); } catch (e) { report(e); } finally { busy = false; } }
      return;
    }
    if (event.target.closest('[data-close-cart]')) { close(); return; }
    if (event.target === drawer()) {
      const rect = drawer().getBoundingClientRect();
      if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) close();
    }
    const change = event.target.closest('[data-change-cart]');
    if (!change || busy) return;
    busy = true;
    drawer().setAttribute('aria-busy', 'true');
    drawer().querySelectorAll('[data-change-cart]').forEach(button => button.disabled = true);
    try {
      const response = await fetch(`${routeRoot()}cart/change.js`, {method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify({id:change.dataset.changeCart,quantity:Number(change.dataset.quantity)})});
      const cart = await response.json();
      if (!response.ok) throw new Error(cart.description || 'Your bag could not be updated.');
      document.querySelectorAll('[data-cart-count]').forEach(el => el.textContent = cart.item_count);
      await refresh();
    } catch(e) { report(e); }
    finally { busy = false; drawer()?.removeAttribute('aria-busy');drawer()?.querySelectorAll('[data-change-cart]').forEach(button => button.disabled = false); }
  });
  document.addEventListener('cancel', event => { if(event.target === drawer()){event.preventDefault();close();} }, true);
  document.addEventListener('present:added', async () => { open(); try { await refresh(); } catch(e) { report(e); } });

  function setupMenus(root = document) {
    root.querySelectorAll('.mega-menu').forEach(menu => {
      if(menu.dataset.ready) return;
      menu.dataset.ready = 'true';
      const summary = menu.querySelector('summary');
      let timer;
      const shut = () => { menu.classList.add('is-closing'); clearTimeout(timer);timer=setTimeout(()=>{menu.open=false;menu.classList.remove('is-closing');},matchMedia('(prefers-reduced-motion: reduce)').matches?0:220); };
      summary.addEventListener('click',event=>{if(menu.open){event.preventDefault();shut();}});
      menu.addEventListener('pointerenter',event=>{if(event.pointerType==='mouse'&&matchMedia('(min-width: 701px)').matches){clearTimeout(timer);menu.classList.remove('is-closing');menu.open=true;}});
      menu.addEventListener('pointerleave',event=>{if(event.pointerType==='mouse'&&matchMedia('(min-width: 701px)').matches&&!menu.contains(document.activeElement))shut();});
      menu.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();shut();summary.focus();}});
      document.addEventListener('click',event=>{if(menu.open&&!menu.contains(event.target))shut();});
      menu.addEventListener('focusout',()=>setTimeout(()=>{if(menu.open&&!menu.contains(document.activeElement)&&!menu.matches(':hover'))shut();},0));
    });
  }
  setupMenus();document.addEventListener('shopify:section:load',event=>setupMenus(event.target));
})();
